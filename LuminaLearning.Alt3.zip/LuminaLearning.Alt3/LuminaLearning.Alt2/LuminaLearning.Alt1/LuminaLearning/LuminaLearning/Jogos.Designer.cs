﻿namespace LuminaLearning
{
    partial class Jogos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            header1 = new Header();
            tableLayoutPanel1 = new TableLayoutPanel();
            panelAbaLateral = new Panel();
            panelAcessos = new Panel();
            lblAcessos = new Label();
            panelPrincipal = new Panel();
            abaMenu1 = new AbaMenu();
            lblTitle3 = new Label();
            lblTitle2 = new Label();
            lblTitle1 = new Label();
            btnJogo12 = new Button();
            btnJogo11 = new Button();
            btnJogo10 = new Button();
            btnJogo9 = new Button();
            btnJogo8 = new Button();
            btnJogo7 = new Button();
            btnJogo6 = new Button();
            btnJogo5 = new Button();
            btnJogo4 = new Button();
            btnJogo3 = new Button();
            btnJogo2 = new Button();
            btnJogo1 = new Button();
            tableLayoutPanel1.SuspendLayout();
            panelAbaLateral.SuspendLayout();
            panelAcessos.SuspendLayout();
            panelPrincipal.SuspendLayout();
            SuspendLayout();
            // 
            // header1
            // 
            header1.Dock = DockStyle.Top;
            header1.Location = new Point(0, 0);
            header1.Name = "header1";
            header1.Size = new Size(1370, 90);
            header1.TabIndex = 0;
            header1.OnMenuClick += header1_OnMenuClick;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.AutoScroll = true;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80F));
            tableLayoutPanel1.Controls.Add(panelAbaLateral, 0, 0);
            tableLayoutPanel1.Controls.Add(panelPrincipal, 1, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 90);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(1370, 659);
            tableLayoutPanel1.TabIndex = 1;
            // 
            // panelAbaLateral
            // 
            panelAbaLateral.AutoScroll = true;
            panelAbaLateral.BackColor = Color.FromArgb(224, 224, 224);
            panelAbaLateral.Controls.Add(panelAcessos);
            panelAbaLateral.Dock = DockStyle.Fill;
            panelAbaLateral.Location = new Point(0, 0);
            panelAbaLateral.Margin = new Padding(0);
            panelAbaLateral.Name = "panelAbaLateral";
            panelAbaLateral.Size = new Size(274, 659);
            panelAbaLateral.TabIndex = 0;
            // 
            // panelAcessos
            // 
            panelAcessos.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panelAcessos.BackColor = Color.Gray;
            panelAcessos.Controls.Add(lblAcessos);
            panelAcessos.Location = new Point(9, 332);
            panelAcessos.Margin = new Padding(0);
            panelAcessos.Name = "panelAcessos";
            panelAcessos.Size = new Size(256, 315);
            panelAcessos.TabIndex = 0;
            // 
            // lblAcessos
            // 
            lblAcessos.AutoSize = true;
            lblAcessos.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAcessos.Location = new Point(69, 15);
            lblAcessos.Name = "lblAcessos";
            lblAcessos.Size = new Size(97, 32);
            lblAcessos.TabIndex = 0;
            lblAcessos.Text = "Acessos";
            // 
            // panelPrincipal
            // 
            panelPrincipal.Controls.Add(abaMenu1);
            panelPrincipal.Controls.Add(lblTitle3);
            panelPrincipal.Controls.Add(lblTitle2);
            panelPrincipal.Controls.Add(lblTitle1);
            panelPrincipal.Controls.Add(btnJogo12);
            panelPrincipal.Controls.Add(btnJogo11);
            panelPrincipal.Controls.Add(btnJogo10);
            panelPrincipal.Controls.Add(btnJogo9);
            panelPrincipal.Controls.Add(btnJogo8);
            panelPrincipal.Controls.Add(btnJogo7);
            panelPrincipal.Controls.Add(btnJogo6);
            panelPrincipal.Controls.Add(btnJogo5);
            panelPrincipal.Controls.Add(btnJogo4);
            panelPrincipal.Controls.Add(btnJogo3);
            panelPrincipal.Controls.Add(btnJogo2);
            panelPrincipal.Controls.Add(btnJogo1);
            panelPrincipal.Dock = DockStyle.Fill;
            panelPrincipal.Location = new Point(277, 3);
            panelPrincipal.Name = "panelPrincipal";
            panelPrincipal.Size = new Size(1090, 653);
            panelPrincipal.TabIndex = 1;
            // 
            // abaMenu1
            // 
            abaMenu1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            abaMenu1.Location = new Point(793, 1);
            abaMenu1.Name = "abaMenu1";
            abaMenu1.Size = new Size(300, 600);
            abaMenu1.TabIndex = 19;
            abaMenu1.Visible = false;
            // 
            // lblTitle3
            // 
            lblTitle3.AutoSize = true;
            lblTitle3.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTitle3.Location = new Point(18, 440);
            lblTitle3.Name = "lblTitle3";
            lblTitle3.Size = new Size(253, 32);
            lblTitle3.TabIndex = 18;
            lblTitle3.Text = "Jogos (Tipo dos jogos)";
            // 
            // lblTitle2
            // 
            lblTitle2.AutoSize = true;
            lblTitle2.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTitle2.Location = new Point(18, 234);
            lblTitle2.Name = "lblTitle2";
            lblTitle2.Size = new Size(253, 32);
            lblTitle2.TabIndex = 17;
            lblTitle2.Text = "Jogos (Tipo dos jogos)";
            // 
            // lblTitle1
            // 
            lblTitle1.AutoSize = true;
            lblTitle1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTitle1.Location = new Point(18, 24);
            lblTitle1.Name = "lblTitle1";
            lblTitle1.Size = new Size(253, 32);
            lblTitle1.TabIndex = 16;
            lblTitle1.Text = "Jogos (Tipo dos jogos)";
            // 
            // btnJogo12
            // 
            btnJogo12.Anchor = AnchorStyles.Bottom;
            btnJogo12.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo12.FlatAppearance.BorderColor = Color.Gray;
            btnJogo12.FlatAppearance.BorderSize = 8;
            btnJogo12.FlatStyle = FlatStyle.Flat;
            btnJogo12.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo12.Location = new Point(816, 489);
            btnJogo12.Name = "btnJogo12";
            btnJogo12.Size = new Size(237, 124);
            btnJogo12.TabIndex = 15;
            btnJogo12.Text = "JOGO 12";
            btnJogo12.UseVisualStyleBackColor = false;
            // 
            // btnJogo11
            // 
            btnJogo11.Anchor = AnchorStyles.Bottom;
            btnJogo11.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo11.FlatAppearance.BorderColor = Color.Gray;
            btnJogo11.FlatAppearance.BorderSize = 8;
            btnJogo11.FlatStyle = FlatStyle.Flat;
            btnJogo11.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo11.Location = new Point(548, 489);
            btnJogo11.Name = "btnJogo11";
            btnJogo11.Size = new Size(237, 124);
            btnJogo11.TabIndex = 14;
            btnJogo11.Text = "JOGO 11";
            btnJogo11.UseVisualStyleBackColor = false;
            // 
            // btnJogo10
            // 
            btnJogo10.Anchor = AnchorStyles.Bottom;
            btnJogo10.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo10.FlatAppearance.BorderColor = Color.Gray;
            btnJogo10.FlatAppearance.BorderSize = 8;
            btnJogo10.FlatStyle = FlatStyle.Flat;
            btnJogo10.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo10.Location = new Point(286, 489);
            btnJogo10.Name = "btnJogo10";
            btnJogo10.Size = new Size(237, 124);
            btnJogo10.TabIndex = 13;
            btnJogo10.Text = "JOGO 10";
            btnJogo10.UseVisualStyleBackColor = false;
            // 
            // btnJogo9
            // 
            btnJogo9.Anchor = AnchorStyles.Bottom;
            btnJogo9.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo9.FlatAppearance.BorderColor = Color.Gray;
            btnJogo9.FlatAppearance.BorderSize = 8;
            btnJogo9.FlatStyle = FlatStyle.Flat;
            btnJogo9.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo9.Location = new Point(18, 489);
            btnJogo9.Name = "btnJogo9";
            btnJogo9.Size = new Size(237, 124);
            btnJogo9.TabIndex = 12;
            btnJogo9.Text = "JOGO 9";
            btnJogo9.UseVisualStyleBackColor = false;
            // 
            // btnJogo8
            // 
            btnJogo8.Anchor = AnchorStyles.Bottom;
            btnJogo8.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo8.FlatAppearance.BorderColor = Color.Gray;
            btnJogo8.FlatAppearance.BorderSize = 8;
            btnJogo8.FlatStyle = FlatStyle.Flat;
            btnJogo8.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo8.Location = new Point(816, 282);
            btnJogo8.Name = "btnJogo8";
            btnJogo8.Size = new Size(237, 124);
            btnJogo8.TabIndex = 11;
            btnJogo8.Text = "JOGO 8";
            btnJogo8.UseVisualStyleBackColor = false;
            // 
            // btnJogo7
            // 
            btnJogo7.Anchor = AnchorStyles.Bottom;
            btnJogo7.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo7.FlatAppearance.BorderColor = Color.Gray;
            btnJogo7.FlatAppearance.BorderSize = 8;
            btnJogo7.FlatStyle = FlatStyle.Flat;
            btnJogo7.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo7.Location = new Point(548, 282);
            btnJogo7.Name = "btnJogo7";
            btnJogo7.Size = new Size(237, 124);
            btnJogo7.TabIndex = 10;
            btnJogo7.Text = "JOGO 7";
            btnJogo7.UseVisualStyleBackColor = false;
            // 
            // btnJogo6
            // 
            btnJogo6.Anchor = AnchorStyles.Bottom;
            btnJogo6.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo6.FlatAppearance.BorderColor = Color.Gray;
            btnJogo6.FlatAppearance.BorderSize = 8;
            btnJogo6.FlatStyle = FlatStyle.Flat;
            btnJogo6.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo6.Location = new Point(286, 282);
            btnJogo6.Name = "btnJogo6";
            btnJogo6.Size = new Size(237, 124);
            btnJogo6.TabIndex = 9;
            btnJogo6.Text = "JOGO 6";
            btnJogo6.UseVisualStyleBackColor = false;
            // 
            // btnJogo5
            // 
            btnJogo5.Anchor = AnchorStyles.Bottom;
            btnJogo5.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo5.FlatAppearance.BorderColor = Color.Gray;
            btnJogo5.FlatAppearance.BorderSize = 8;
            btnJogo5.FlatStyle = FlatStyle.Flat;
            btnJogo5.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo5.Location = new Point(18, 282);
            btnJogo5.Name = "btnJogo5";
            btnJogo5.Size = new Size(237, 124);
            btnJogo5.TabIndex = 8;
            btnJogo5.Text = "JOGO 5";
            btnJogo5.UseVisualStyleBackColor = false;
            // 
            // btnJogo4
            // 
            btnJogo4.Anchor = AnchorStyles.Bottom;
            btnJogo4.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo4.FlatAppearance.BorderColor = Color.Gray;
            btnJogo4.FlatAppearance.BorderSize = 8;
            btnJogo4.FlatStyle = FlatStyle.Flat;
            btnJogo4.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo4.Location = new Point(816, 71);
            btnJogo4.Name = "btnJogo4";
            btnJogo4.Size = new Size(237, 124);
            btnJogo4.TabIndex = 7;
            btnJogo4.Text = "JOGO 4";
            btnJogo4.UseVisualStyleBackColor = false;
            // 
            // btnJogo3
            // 
            btnJogo3.Anchor = AnchorStyles.Bottom;
            btnJogo3.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo3.FlatAppearance.BorderColor = Color.Gray;
            btnJogo3.FlatAppearance.BorderSize = 8;
            btnJogo3.FlatStyle = FlatStyle.Flat;
            btnJogo3.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo3.Location = new Point(548, 71);
            btnJogo3.Name = "btnJogo3";
            btnJogo3.Size = new Size(237, 124);
            btnJogo3.TabIndex = 6;
            btnJogo3.Text = "JOGO 3";
            btnJogo3.UseVisualStyleBackColor = false;
            // 
            // btnJogo2
            // 
            btnJogo2.Anchor = AnchorStyles.Bottom;
            btnJogo2.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo2.FlatAppearance.BorderColor = Color.Gray;
            btnJogo2.FlatAppearance.BorderSize = 8;
            btnJogo2.FlatStyle = FlatStyle.Flat;
            btnJogo2.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo2.Location = new Point(286, 71);
            btnJogo2.Name = "btnJogo2";
            btnJogo2.Size = new Size(237, 124);
            btnJogo2.TabIndex = 5;
            btnJogo2.Text = "JOGO 2";
            btnJogo2.UseVisualStyleBackColor = false;
            // 
            // btnJogo1
            // 
            btnJogo1.Anchor = AnchorStyles.Bottom;
            btnJogo1.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo1.FlatAppearance.BorderColor = Color.Gray;
            btnJogo1.FlatAppearance.BorderSize = 8;
            btnJogo1.FlatStyle = FlatStyle.Flat;
            btnJogo1.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo1.Location = new Point(18, 71);
            btnJogo1.Name = "btnJogo1";
            btnJogo1.Size = new Size(237, 124);
            btnJogo1.TabIndex = 4;
            btnJogo1.Text = "JOGO 1";
            btnJogo1.UseVisualStyleBackColor = false;
            // 
            // Jogos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1370, 749);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(header1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Jogos";
            Text = "Jogos";
            Load += Jogos_Load;
            tableLayoutPanel1.ResumeLayout(false);
            panelAbaLateral.ResumeLayout(false);
            panelAcessos.ResumeLayout(false);
            panelAcessos.PerformLayout();
            panelPrincipal.ResumeLayout(false);
            panelPrincipal.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Header header1;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panelAbaLateral;
        private Panel panelAcessos;
        private Panel panelPrincipal;
        private Label lblTitle1;
        private Button btnJogo12;
        private Button btnJogo11;
        private Button btnJogo10;
        private Button btnJogo9;
        private Button btnJogo8;
        private Button btnJogo7;
        private Button btnJogo6;
        private Button btnJogo5;
        private Button btnJogo4;
        private Button btnJogo3;
        private Button btnJogo2;
        private Button btnJogo1;
        private Label lblTitle3;
        private Label lblTitle2;
        private Label lblAcessos;
        private AbaMenu abaMenu1;
    }
}