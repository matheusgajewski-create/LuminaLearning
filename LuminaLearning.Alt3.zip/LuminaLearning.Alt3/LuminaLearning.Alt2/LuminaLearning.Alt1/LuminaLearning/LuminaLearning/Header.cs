﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LuminaLearning
{
    public partial class Header : UserControl
    {
        public event EventHandler OnMenuClick;
        public Header()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OnMenuClick?.Invoke(this, e);
        }
    }
}
