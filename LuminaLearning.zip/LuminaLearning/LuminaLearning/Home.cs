namespace LuminaLearning
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {

        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {

        }

        private void lblMessier_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cadastro tela = new Cadastro();
            tela.Show();
        }
    }
}
