﻿namespace LuminaLearning
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            header1 = new Header();
            txtSenha = new TextBox();
            txtID = new TextBox();
            lblLogin = new Label();
            button1 = new Button();
            abaMenu1 = new AbaMenu();
            SuspendLayout();
            // 
            // header1
            // 
            header1.Dock = DockStyle.Top;
            header1.Location = new Point(0, 0);
            header1.Name = "header1";
            header1.Size = new Size(1370, 90);
            header1.TabIndex = 0;
            // 
            // txtSenha
            // 
            txtSenha.BackColor = Color.FromArgb(224, 224, 224);
            txtSenha.BorderStyle = BorderStyle.FixedSingle;
            txtSenha.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtSenha.Location = new Point(452, 473);
            txtSenha.Multiline = true;
            txtSenha.Name = "txtSenha";
            txtSenha.PlaceholderText = "Senha";
            txtSenha.Size = new Size(548, 58);
            txtSenha.TabIndex = 1;
            // 
            // txtID
            // 
            txtID.BackColor = Color.FromArgb(224, 224, 224);
            txtID.BorderStyle = BorderStyle.FixedSingle;
            txtID.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtID.Location = new Point(452, 391);
            txtID.Multiline = true;
            txtID.Name = "txtID";
            txtID.PlaceholderText = "Identificador";
            txtID.Size = new Size(548, 58);
            txtID.TabIndex = 2;
            // 
            // lblLogin
            // 
            lblLogin.AutoSize = true;
            lblLogin.BackColor = Color.Silver;
            lblLogin.FlatStyle = FlatStyle.Flat;
            lblLogin.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblLogin.Location = new Point(452, 287);
            lblLogin.Name = "lblLogin";
            lblLogin.Size = new Size(146, 65);
            lblLogin.TabIndex = 3;
            lblLogin.Text = "Login";
            // 
            // button1
            // 
            button1.Location = new Point(228, 221);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 4;
            button1.Text = "teste";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // abaMenu1
            // 
            abaMenu1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            abaMenu1.Location = new Point(1070, 90);
            abaMenu1.Name = "abaMenu1";
            abaMenu1.Size = new Size(300, 600);
            abaMenu1.TabIndex = 5;
            abaMenu1.Visible = false;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1370, 749);
            Controls.Add(abaMenu1);
            Controls.Add(button1);
            Controls.Add(lblLogin);
            Controls.Add(txtID);
            Controls.Add(txtSenha);
            Controls.Add(header1);
            Name = "Login";
            Text = "Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Header header1;
        private TextBox txtSenha;
        private TextBox txtID;
        private Label lblLogin;
        private Button button1;
        private AbaMenu abaMenu1;
    }
}