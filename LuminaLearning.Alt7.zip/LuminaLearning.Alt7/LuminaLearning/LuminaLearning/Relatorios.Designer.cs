﻿namespace LuminaLearning
{
    partial class Relatorios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            header1 = new Header();
            abaMenu1 = new AbaMenu();
            abaProfile1 = new abaProfile();
            abaSair1 = new abaSair();
            tableLayoutPanel1 = new TableLayoutPanel();
            panelTurmas = new Panel();
            panel3Serie = new Panel();
            btn3sA = new Button();
            btn3sB = new Button();
            btn3sC = new Button();
            lbl3Serie = new Label();
            panel2Serie = new Panel();
            btn2sA = new Button();
            btn2sB = new Button();
            btn2sC = new Button();
            lbl2Serie = new Label();
            panel1Serie = new Panel();
            btn1sA = new Button();
            btn1sB = new Button();
            btn1sC = new Button();
            lbl1Serie = new Label();
            panel9Ano = new Panel();
            btn9A = new Button();
            btn9B = new Button();
            btn9C = new Button();
            lbl9Ano = new Label();
            panel8Ano = new Panel();
            btn8A = new Button();
            btn8B = new Button();
            btn8C = new Button();
            lbl8Ano = new Label();
            panel7Ano = new Panel();
            btn7A = new Button();
            btn7B = new Button();
            btn7C = new Button();
            lbl7Ano = new Label();
            panel6Ano = new Panel();
            btn6A = new Button();
            btn6B = new Button();
            btn6C = new Button();
            lbl6ano = new Label();
            panel5Ano = new Panel();
            btn5A = new Button();
            btn5B = new Button();
            btn5C = new Button();
            lbl5Ano = new Label();
            panel4Ano = new Panel();
            btn4C = new Button();
            btn4B = new Button();
            btn4A = new Button();
            lbl4Ano = new Label();
            panel3Ano = new Panel();
            btn3A = new Button();
            btn3B = new Button();
            btn3C = new Button();
            lbl3Ano = new Label();
            panel2Ano = new Panel();
            btn2C = new Button();
            btn2B = new Button();
            btn2A = new Button();
            lbl2Ano = new Label();
            panel1Ano = new Panel();
            btn1C = new Button();
            btn1B = new Button();
            btn1A = new Button();
            lbl1Ano = new Label();
            lblEnsinoMedio = new Label();
            lblFundamental2 = new Label();
            lblFundamental1 = new Label();
            lblTurmas = new Label();
            panelRelatorioAno = new Panel();
            lblRelatorioAno = new Label();
            tableLayoutPanel1.SuspendLayout();
            panelTurmas.SuspendLayout();
            panel3Serie.SuspendLayout();
            panel2Serie.SuspendLayout();
            panel1Serie.SuspendLayout();
            panel9Ano.SuspendLayout();
            panel8Ano.SuspendLayout();
            panel7Ano.SuspendLayout();
            panel6Ano.SuspendLayout();
            panel5Ano.SuspendLayout();
            panel4Ano.SuspendLayout();
            panel3Ano.SuspendLayout();
            panel2Ano.SuspendLayout();
            panel1Ano.SuspendLayout();
            panelRelatorioAno.SuspendLayout();
            SuspendLayout();
            // 
            // header1
            // 
            header1.Dock = DockStyle.Top;
            header1.Location = new Point(0, 0);
            header1.Name = "header1";
            header1.Size = new Size(1370, 90);
            header1.TabIndex = 1;
            header1.OnMenuClick += header1_OnMenuClick;
            header1.OnbtnProfile += header1_OnbtnProfile;
            // 
            // abaMenu1
            // 
            abaMenu1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            abaMenu1.Location = new Point(1070, 90);
            abaMenu1.Name = "abaMenu1";
            abaMenu1.Size = new Size(300, 600);
            abaMenu1.TabIndex = 2;
            abaMenu1.Visible = false;
            abaMenu1.OnbtnHomeClick += abaMenu1_OnbtnHomeClick;
            abaMenu1.OnbtnJogosClick += abaMenu1_OnbtnJogosClick;
            abaMenu1.OnbtnSairClick += abaMenu1_OnbtnSairClick;
            abaMenu1.OnbtnRelatoriosClick += abaMenu1_OnbtnRelatoriosClick;
            abaMenu1.OnbtnMonitoramentoClick += abaMenu1_OnbtnMonitoramentoClick;
            abaMenu1.OnbtnIPsClick += abaMenu1_OnbtnIPsClick;
            // 
            // abaProfile1
            // 
            abaProfile1.BackColor = Color.FromArgb(224, 224, 224);
            abaProfile1.Location = new Point(804, 90);
            abaProfile1.Name = "abaProfile1";
            abaProfile1.Size = new Size(570, 200);
            abaProfile1.TabIndex = 3;
            abaProfile1.Visible = false;
            abaProfile1.OnbtnSairClick += abaProfile1_OnbtnSairClick;
            // 
            // abaSair1
            // 
            abaSair1.BackColor = Color.FromArgb(224, 224, 224);
            abaSair1.Location = new Point(531, 329);
            abaSair1.Name = "abaSair1";
            abaSair1.Size = new Size(309, 146);
            abaSair1.TabIndex = 4;
            abaSair1.Visible = false;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80F));
            tableLayoutPanel1.Controls.Add(panelTurmas, 0, 0);
            tableLayoutPanel1.Controls.Add(panelRelatorioAno, 1, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 90);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(1370, 659);
            tableLayoutPanel1.TabIndex = 5;
            // 
            // panelTurmas
            // 
            panelTurmas.BackColor = Color.FromArgb(224, 224, 224);
            panelTurmas.Controls.Add(panel3Serie);
            panelTurmas.Controls.Add(panel2Serie);
            panelTurmas.Controls.Add(panel1Serie);
            panelTurmas.Controls.Add(panel9Ano);
            panelTurmas.Controls.Add(panel8Ano);
            panelTurmas.Controls.Add(panel7Ano);
            panelTurmas.Controls.Add(panel6Ano);
            panelTurmas.Controls.Add(panel5Ano);
            panelTurmas.Controls.Add(panel4Ano);
            panelTurmas.Controls.Add(panel3Ano);
            panelTurmas.Controls.Add(panel2Ano);
            panelTurmas.Controls.Add(panel1Ano);
            panelTurmas.Controls.Add(lblEnsinoMedio);
            panelTurmas.Controls.Add(lblFundamental2);
            panelTurmas.Controls.Add(lblFundamental1);
            panelTurmas.Controls.Add(lblTurmas);
            panelTurmas.Dock = DockStyle.Fill;
            panelTurmas.Location = new Point(3, 3);
            panelTurmas.Name = "panelTurmas";
            panelTurmas.Size = new Size(268, 653);
            panelTurmas.TabIndex = 0;
            // 
            // panel3Serie
            // 
            panel3Serie.BackColor = Color.Gray;
            panel3Serie.Controls.Add(btn3sA);
            panel3Serie.Controls.Add(btn3sB);
            panel3Serie.Controls.Add(btn3sC);
            panel3Serie.Controls.Add(lbl3Serie);
            panel3Serie.Location = new Point(181, 511);
            panel3Serie.Name = "panel3Serie";
            panel3Serie.Size = new Size(82, 56);
            panel3Serie.TabIndex = 13;
            // 
            // btn3sA
            // 
            btn3sA.Location = new Point(0, 30);
            btn3sA.Name = "btn3sA";
            btn3sA.Size = new Size(29, 23);
            btn3sA.TabIndex = 10;
            btn3sA.Text = "A";
            btn3sA.UseVisualStyleBackColor = true;
            // 
            // btn3sB
            // 
            btn3sB.Location = new Point(27, 30);
            btn3sB.Name = "btn3sB";
            btn3sB.Size = new Size(29, 23);
            btn3sB.TabIndex = 9;
            btn3sB.Text = "B";
            btn3sB.UseVisualStyleBackColor = true;
            // 
            // btn3sC
            // 
            btn3sC.Location = new Point(54, 30);
            btn3sC.Name = "btn3sC";
            btn3sC.Size = new Size(29, 23);
            btn3sC.TabIndex = 9;
            btn3sC.Text = "C";
            btn3sC.UseVisualStyleBackColor = true;
            // 
            // lbl3Serie
            // 
            lbl3Serie.AutoSize = true;
            lbl3Serie.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl3Serie.ForeColor = Color.White;
            lbl3Serie.Location = new Point(14, 4);
            lbl3Serie.Name = "lbl3Serie";
            lbl3Serie.Size = new Size(55, 17);
            lbl3Serie.TabIndex = 3;
            lbl3Serie.Text = "3º Série";
            // 
            // panel2Serie
            // 
            panel2Serie.BackColor = Color.Gray;
            panel2Serie.Controls.Add(btn2sA);
            panel2Serie.Controls.Add(btn2sB);
            panel2Serie.Controls.Add(btn2sC);
            panel2Serie.Controls.Add(lbl2Serie);
            panel2Serie.Location = new Point(93, 511);
            panel2Serie.Name = "panel2Serie";
            panel2Serie.Size = new Size(82, 56);
            panel2Serie.TabIndex = 13;
            // 
            // btn2sA
            // 
            btn2sA.Location = new Point(0, 30);
            btn2sA.Name = "btn2sA";
            btn2sA.Size = new Size(29, 23);
            btn2sA.TabIndex = 10;
            btn2sA.Text = "A";
            btn2sA.UseVisualStyleBackColor = true;
            // 
            // btn2sB
            // 
            btn2sB.Location = new Point(27, 30);
            btn2sB.Name = "btn2sB";
            btn2sB.Size = new Size(29, 23);
            btn2sB.TabIndex = 9;
            btn2sB.Text = "B";
            btn2sB.UseVisualStyleBackColor = true;
            // 
            // btn2sC
            // 
            btn2sC.Location = new Point(54, 30);
            btn2sC.Name = "btn2sC";
            btn2sC.Size = new Size(29, 23);
            btn2sC.TabIndex = 9;
            btn2sC.Text = "C";
            btn2sC.UseVisualStyleBackColor = true;
            // 
            // lbl2Serie
            // 
            lbl2Serie.AutoSize = true;
            lbl2Serie.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl2Serie.ForeColor = Color.White;
            lbl2Serie.Location = new Point(14, 4);
            lbl2Serie.Name = "lbl2Serie";
            lbl2Serie.Size = new Size(59, 17);
            lbl2Serie.TabIndex = 3;
            lbl2Serie.Text = "2º Série ";
            // 
            // panel1Serie
            // 
            panel1Serie.BackColor = Color.Gray;
            panel1Serie.Controls.Add(btn1sA);
            panel1Serie.Controls.Add(btn1sB);
            panel1Serie.Controls.Add(btn1sC);
            panel1Serie.Controls.Add(lbl1Serie);
            panel1Serie.Location = new Point(5, 511);
            panel1Serie.Name = "panel1Serie";
            panel1Serie.Size = new Size(82, 56);
            panel1Serie.TabIndex = 13;
            // 
            // btn1sA
            // 
            btn1sA.Location = new Point(0, 30);
            btn1sA.Name = "btn1sA";
            btn1sA.Size = new Size(29, 23);
            btn1sA.TabIndex = 10;
            btn1sA.Text = "A";
            btn1sA.UseVisualStyleBackColor = true;
            // 
            // btn1sB
            // 
            btn1sB.Location = new Point(27, 30);
            btn1sB.Name = "btn1sB";
            btn1sB.Size = new Size(29, 23);
            btn1sB.TabIndex = 9;
            btn1sB.Text = "B";
            btn1sB.UseVisualStyleBackColor = true;
            // 
            // btn1sC
            // 
            btn1sC.Location = new Point(54, 30);
            btn1sC.Name = "btn1sC";
            btn1sC.Size = new Size(29, 23);
            btn1sC.TabIndex = 9;
            btn1sC.Text = "C";
            btn1sC.UseVisualStyleBackColor = true;
            // 
            // lbl1Serie
            // 
            lbl1Serie.AutoSize = true;
            lbl1Serie.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl1Serie.ForeColor = Color.White;
            lbl1Serie.Location = new Point(14, 4);
            lbl1Serie.Name = "lbl1Serie";
            lbl1Serie.Size = new Size(59, 17);
            lbl1Serie.TabIndex = 3;
            lbl1Serie.Text = "1º Série ";
            // 
            // panel9Ano
            // 
            panel9Ano.BackColor = Color.Gray;
            panel9Ano.Controls.Add(btn9A);
            panel9Ano.Controls.Add(btn9B);
            panel9Ano.Controls.Add(btn9C);
            panel9Ano.Controls.Add(lbl9Ano);
            panel9Ano.Location = new Point(137, 424);
            panel9Ano.Name = "panel9Ano";
            panel9Ano.Size = new Size(82, 56);
            panel9Ano.TabIndex = 12;
            // 
            // btn9A
            // 
            btn9A.Location = new Point(0, 30);
            btn9A.Name = "btn9A";
            btn9A.Size = new Size(29, 23);
            btn9A.TabIndex = 10;
            btn9A.Text = "A";
            btn9A.UseVisualStyleBackColor = true;
            // 
            // btn9B
            // 
            btn9B.Location = new Point(27, 30);
            btn9B.Name = "btn9B";
            btn9B.Size = new Size(29, 23);
            btn9B.TabIndex = 9;
            btn9B.Text = "B";
            btn9B.UseVisualStyleBackColor = true;
            // 
            // btn9C
            // 
            btn9C.Location = new Point(54, 30);
            btn9C.Name = "btn9C";
            btn9C.Size = new Size(29, 23);
            btn9C.TabIndex = 9;
            btn9C.Text = "C";
            btn9C.UseVisualStyleBackColor = true;
            // 
            // lbl9Ano
            // 
            lbl9Ano.AutoSize = true;
            lbl9Ano.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl9Ano.ForeColor = Color.White;
            lbl9Ano.Location = new Point(14, 4);
            lbl9Ano.Name = "lbl9Ano";
            lbl9Ano.Size = new Size(54, 17);
            lbl9Ano.TabIndex = 3;
            lbl9Ano.Text = "9º ANO";
            // 
            // panel8Ano
            // 
            panel8Ano.BackColor = Color.Gray;
            panel8Ano.Controls.Add(btn8A);
            panel8Ano.Controls.Add(btn8B);
            panel8Ano.Controls.Add(btn8C);
            panel8Ano.Controls.Add(lbl8Ano);
            panel8Ano.Location = new Point(49, 424);
            panel8Ano.Name = "panel8Ano";
            panel8Ano.Size = new Size(82, 56);
            panel8Ano.TabIndex = 12;
            // 
            // btn8A
            // 
            btn8A.Location = new Point(0, 30);
            btn8A.Name = "btn8A";
            btn8A.Size = new Size(29, 23);
            btn8A.TabIndex = 10;
            btn8A.Text = "A";
            btn8A.UseVisualStyleBackColor = true;
            // 
            // btn8B
            // 
            btn8B.Location = new Point(27, 30);
            btn8B.Name = "btn8B";
            btn8B.Size = new Size(29, 23);
            btn8B.TabIndex = 9;
            btn8B.Text = "B";
            btn8B.UseVisualStyleBackColor = true;
            // 
            // btn8C
            // 
            btn8C.Location = new Point(54, 30);
            btn8C.Name = "btn8C";
            btn8C.Size = new Size(29, 23);
            btn8C.TabIndex = 9;
            btn8C.Text = "C";
            btn8C.UseVisualStyleBackColor = true;
            // 
            // lbl8Ano
            // 
            lbl8Ano.AutoSize = true;
            lbl8Ano.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl8Ano.ForeColor = Color.White;
            lbl8Ano.Location = new Point(14, 4);
            lbl8Ano.Name = "lbl8Ano";
            lbl8Ano.Size = new Size(54, 17);
            lbl8Ano.TabIndex = 3;
            lbl8Ano.Text = "8º ANO";
            // 
            // panel7Ano
            // 
            panel7Ano.BackColor = Color.Gray;
            panel7Ano.Controls.Add(btn7A);
            panel7Ano.Controls.Add(btn7B);
            panel7Ano.Controls.Add(btn7C);
            panel7Ano.Controls.Add(lbl7Ano);
            panel7Ano.Location = new Point(137, 362);
            panel7Ano.Name = "panel7Ano";
            panel7Ano.Size = new Size(82, 56);
            panel7Ano.TabIndex = 12;
            // 
            // btn7A
            // 
            btn7A.Location = new Point(0, 30);
            btn7A.Name = "btn7A";
            btn7A.Size = new Size(29, 23);
            btn7A.TabIndex = 10;
            btn7A.Text = "A";
            btn7A.UseVisualStyleBackColor = true;
            // 
            // btn7B
            // 
            btn7B.Location = new Point(27, 30);
            btn7B.Name = "btn7B";
            btn7B.Size = new Size(29, 23);
            btn7B.TabIndex = 9;
            btn7B.Text = "B";
            btn7B.UseVisualStyleBackColor = true;
            // 
            // btn7C
            // 
            btn7C.Location = new Point(54, 30);
            btn7C.Name = "btn7C";
            btn7C.Size = new Size(29, 23);
            btn7C.TabIndex = 9;
            btn7C.Text = "C";
            btn7C.UseVisualStyleBackColor = true;
            // 
            // lbl7Ano
            // 
            lbl7Ano.AutoSize = true;
            lbl7Ano.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl7Ano.ForeColor = Color.White;
            lbl7Ano.Location = new Point(14, 4);
            lbl7Ano.Name = "lbl7Ano";
            lbl7Ano.Size = new Size(54, 17);
            lbl7Ano.TabIndex = 3;
            lbl7Ano.Text = "7º ANO";
            // 
            // panel6Ano
            // 
            panel6Ano.BackColor = Color.Gray;
            panel6Ano.Controls.Add(btn6A);
            panel6Ano.Controls.Add(btn6B);
            panel6Ano.Controls.Add(btn6C);
            panel6Ano.Controls.Add(lbl6ano);
            panel6Ano.Location = new Point(49, 362);
            panel6Ano.Name = "panel6Ano";
            panel6Ano.Size = new Size(82, 56);
            panel6Ano.TabIndex = 11;
            // 
            // btn6A
            // 
            btn6A.Location = new Point(0, 30);
            btn6A.Name = "btn6A";
            btn6A.Size = new Size(29, 23);
            btn6A.TabIndex = 10;
            btn6A.Text = "A";
            btn6A.UseVisualStyleBackColor = true;
            // 
            // btn6B
            // 
            btn6B.Location = new Point(27, 30);
            btn6B.Name = "btn6B";
            btn6B.Size = new Size(29, 23);
            btn6B.TabIndex = 9;
            btn6B.Text = "B";
            btn6B.UseVisualStyleBackColor = true;
            // 
            // btn6C
            // 
            btn6C.Location = new Point(54, 30);
            btn6C.Name = "btn6C";
            btn6C.Size = new Size(29, 23);
            btn6C.TabIndex = 9;
            btn6C.Text = "C";
            btn6C.UseVisualStyleBackColor = true;
            // 
            // lbl6ano
            // 
            lbl6ano.AutoSize = true;
            lbl6ano.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl6ano.ForeColor = Color.White;
            lbl6ano.Location = new Point(14, 4);
            lbl6ano.Name = "lbl6ano";
            lbl6ano.Size = new Size(54, 17);
            lbl6ano.TabIndex = 3;
            lbl6ano.Text = "6º ANO";
            // 
            // panel5Ano
            // 
            panel5Ano.BackColor = Color.Gray;
            panel5Ano.Controls.Add(btn5A);
            panel5Ano.Controls.Add(btn5B);
            panel5Ano.Controls.Add(btn5C);
            panel5Ano.Controls.Add(lbl5Ano);
            panel5Ano.Location = new Point(137, 280);
            panel5Ano.Name = "panel5Ano";
            panel5Ano.Size = new Size(82, 56);
            panel5Ano.TabIndex = 5;
            // 
            // btn5A
            // 
            btn5A.Location = new Point(0, 30);
            btn5A.Name = "btn5A";
            btn5A.Size = new Size(29, 23);
            btn5A.TabIndex = 10;
            btn5A.Text = "A";
            btn5A.UseVisualStyleBackColor = true;
            // 
            // btn5B
            // 
            btn5B.Location = new Point(27, 30);
            btn5B.Name = "btn5B";
            btn5B.Size = new Size(29, 23);
            btn5B.TabIndex = 9;
            btn5B.Text = "B";
            btn5B.UseVisualStyleBackColor = true;
            // 
            // btn5C
            // 
            btn5C.Location = new Point(54, 30);
            btn5C.Name = "btn5C";
            btn5C.Size = new Size(29, 23);
            btn5C.TabIndex = 9;
            btn5C.Text = "C";
            btn5C.UseVisualStyleBackColor = true;
            // 
            // lbl5Ano
            // 
            lbl5Ano.AutoSize = true;
            lbl5Ano.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl5Ano.ForeColor = Color.White;
            lbl5Ano.Location = new Point(14, 4);
            lbl5Ano.Name = "lbl5Ano";
            lbl5Ano.Size = new Size(54, 17);
            lbl5Ano.TabIndex = 3;
            lbl5Ano.Text = "5º ANO";
            // 
            // panel4Ano
            // 
            panel4Ano.BackColor = Color.Gray;
            panel4Ano.Controls.Add(btn4C);
            panel4Ano.Controls.Add(btn4B);
            panel4Ano.Controls.Add(btn4A);
            panel4Ano.Controls.Add(lbl4Ano);
            panel4Ano.Location = new Point(49, 280);
            panel4Ano.Name = "panel4Ano";
            panel4Ano.Size = new Size(82, 56);
            panel4Ano.TabIndex = 6;
            // 
            // btn4C
            // 
            btn4C.Location = new Point(54, 30);
            btn4C.Name = "btn4C";
            btn4C.Size = new Size(29, 23);
            btn4C.TabIndex = 9;
            btn4C.Text = "C";
            btn4C.UseVisualStyleBackColor = true;
            // 
            // btn4B
            // 
            btn4B.Location = new Point(27, 30);
            btn4B.Name = "btn4B";
            btn4B.Size = new Size(29, 23);
            btn4B.TabIndex = 9;
            btn4B.Text = "B";
            btn4B.UseVisualStyleBackColor = true;
            // 
            // btn4A
            // 
            btn4A.Location = new Point(0, 30);
            btn4A.Name = "btn4A";
            btn4A.Size = new Size(29, 23);
            btn4A.TabIndex = 9;
            btn4A.Text = "A";
            btn4A.UseVisualStyleBackColor = true;
            // 
            // lbl4Ano
            // 
            lbl4Ano.AutoSize = true;
            lbl4Ano.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl4Ano.ForeColor = Color.White;
            lbl4Ano.Location = new Point(14, 4);
            lbl4Ano.Name = "lbl4Ano";
            lbl4Ano.Size = new Size(54, 17);
            lbl4Ano.TabIndex = 2;
            lbl4Ano.Text = "4º ANO";
            // 
            // panel3Ano
            // 
            panel3Ano.BackColor = Color.Gray;
            panel3Ano.Controls.Add(btn3A);
            panel3Ano.Controls.Add(btn3B);
            panel3Ano.Controls.Add(btn3C);
            panel3Ano.Controls.Add(lbl3Ano);
            panel3Ano.Location = new Point(181, 214);
            panel3Ano.Name = "panel3Ano";
            panel3Ano.Size = new Size(82, 56);
            panel3Ano.TabIndex = 5;
            // 
            // btn3A
            // 
            btn3A.Location = new Point(0, 30);
            btn3A.Name = "btn3A";
            btn3A.Size = new Size(29, 23);
            btn3A.TabIndex = 9;
            btn3A.Text = "A";
            btn3A.UseVisualStyleBackColor = true;
            // 
            // btn3B
            // 
            btn3B.Location = new Point(27, 30);
            btn3B.Name = "btn3B";
            btn3B.Size = new Size(29, 23);
            btn3B.TabIndex = 9;
            btn3B.Text = "B";
            btn3B.UseVisualStyleBackColor = true;
            // 
            // btn3C
            // 
            btn3C.Location = new Point(54, 30);
            btn3C.Name = "btn3C";
            btn3C.Size = new Size(29, 23);
            btn3C.TabIndex = 8;
            btn3C.Text = "C";
            btn3C.UseVisualStyleBackColor = true;
            // 
            // lbl3Ano
            // 
            lbl3Ano.AutoSize = true;
            lbl3Ano.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl3Ano.ForeColor = Color.White;
            lbl3Ano.Location = new Point(14, 4);
            lbl3Ano.Name = "lbl3Ano";
            lbl3Ano.Size = new Size(54, 17);
            lbl3Ano.TabIndex = 1;
            lbl3Ano.Text = "3º ANO";
            // 
            // panel2Ano
            // 
            panel2Ano.BackColor = Color.Gray;
            panel2Ano.Controls.Add(btn2C);
            panel2Ano.Controls.Add(btn2B);
            panel2Ano.Controls.Add(btn2A);
            panel2Ano.Controls.Add(lbl2Ano);
            panel2Ano.Location = new Point(93, 214);
            panel2Ano.Name = "panel2Ano";
            panel2Ano.Size = new Size(82, 56);
            panel2Ano.TabIndex = 5;
            // 
            // btn2C
            // 
            btn2C.Location = new Point(53, 30);
            btn2C.Name = "btn2C";
            btn2C.Size = new Size(29, 23);
            btn2C.TabIndex = 8;
            btn2C.Text = "C";
            btn2C.UseVisualStyleBackColor = true;
            // 
            // btn2B
            // 
            btn2B.Location = new Point(27, 30);
            btn2B.Name = "btn2B";
            btn2B.Size = new Size(29, 23);
            btn2B.TabIndex = 8;
            btn2B.Text = "B";
            btn2B.UseVisualStyleBackColor = true;
            // 
            // btn2A
            // 
            btn2A.Location = new Point(0, 30);
            btn2A.Name = "btn2A";
            btn2A.Size = new Size(29, 23);
            btn2A.TabIndex = 8;
            btn2A.Text = "A";
            btn2A.UseVisualStyleBackColor = true;
            // 
            // lbl2Ano
            // 
            lbl2Ano.AutoSize = true;
            lbl2Ano.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl2Ano.ForeColor = Color.White;
            lbl2Ano.Location = new Point(14, 4);
            lbl2Ano.Name = "lbl2Ano";
            lbl2Ano.Size = new Size(54, 17);
            lbl2Ano.TabIndex = 1;
            lbl2Ano.Text = "2º ANO";
            // 
            // panel1Ano
            // 
            panel1Ano.BackColor = Color.Gray;
            panel1Ano.Controls.Add(btn1C);
            panel1Ano.Controls.Add(btn1B);
            panel1Ano.Controls.Add(btn1A);
            panel1Ano.Controls.Add(lbl1Ano);
            panel1Ano.Location = new Point(5, 214);
            panel1Ano.Name = "panel1Ano";
            panel1Ano.Size = new Size(82, 56);
            panel1Ano.TabIndex = 4;
            // 
            // btn1C
            // 
            btn1C.Location = new Point(53, 30);
            btn1C.Name = "btn1C";
            btn1C.Size = new Size(29, 23);
            btn1C.TabIndex = 7;
            btn1C.Text = "C";
            btn1C.UseVisualStyleBackColor = true;
            // 
            // btn1B
            // 
            btn1B.Location = new Point(27, 30);
            btn1B.Name = "btn1B";
            btn1B.Size = new Size(29, 23);
            btn1B.TabIndex = 2;
            btn1B.Text = "B";
            btn1B.UseVisualStyleBackColor = true;
            // 
            // btn1A
            // 
            btn1A.Location = new Point(0, 30);
            btn1A.Name = "btn1A";
            btn1A.Size = new Size(29, 23);
            btn1A.TabIndex = 1;
            btn1A.Text = "A";
            btn1A.UseVisualStyleBackColor = true;
            // 
            // lbl1Ano
            // 
            lbl1Ano.AutoSize = true;
            lbl1Ano.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl1Ano.ForeColor = Color.White;
            lbl1Ano.Location = new Point(14, 4);
            lbl1Ano.Name = "lbl1Ano";
            lbl1Ano.Size = new Size(54, 17);
            lbl1Ano.TabIndex = 0;
            lbl1Ano.Text = "1º ANO";
            // 
            // lblEnsinoMedio
            // 
            lblEnsinoMedio.AutoSize = true;
            lblEnsinoMedio.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEnsinoMedio.Location = new Point(70, 483);
            lblEnsinoMedio.Name = "lblEnsinoMedio";
            lblEnsinoMedio.Size = new Size(128, 25);
            lblEnsinoMedio.TabIndex = 3;
            lblEnsinoMedio.Text = "Ensino Médio";
            // 
            // lblFundamental2
            // 
            lblFundamental2.AutoSize = true;
            lblFundamental2.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblFundamental2.Location = new Point(35, 334);
            lblFundamental2.Name = "lblFundamental2";
            lblFundamental2.Size = new Size(202, 25);
            lblFundamental2.TabIndex = 2;
            lblFundamental2.Text = "Ensino Fundamental 2";
            // 
            // lblFundamental1
            // 
            lblFundamental1.AutoSize = true;
            lblFundamental1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblFundamental1.Location = new Point(35, 186);
            lblFundamental1.Name = "lblFundamental1";
            lblFundamental1.Size = new Size(199, 25);
            lblFundamental1.TabIndex = 1;
            lblFundamental1.Text = "Ensino Fundamental 1";
            // 
            // lblTurmas
            // 
            lblTurmas.AutoSize = true;
            lblTurmas.Font = new Font("Segoe UI", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTurmas.Location = new Point(44, 37);
            lblTurmas.Name = "lblTurmas";
            lblTurmas.Size = new Size(181, 100);
            lblTurmas.TabIndex = 0;
            lblTurmas.Text = "Turmas\r\nEscolares\r\n";
            lblTurmas.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panelRelatorioAno
            // 
            panelRelatorioAno.Anchor = AnchorStyles.Top;
            panelRelatorioAno.BackColor = Color.Gray;
            panelRelatorioAno.Controls.Add(lblRelatorioAno);
            panelRelatorioAno.Location = new Point(320, 20);
            panelRelatorioAno.Margin = new Padding(3, 20, 3, 3);
            panelRelatorioAno.Name = "panelRelatorioAno";
            panelRelatorioAno.Size = new Size(1003, 120);
            panelRelatorioAno.TabIndex = 1;
            // 
            // lblRelatorioAno
            // 
            lblRelatorioAno.AutoSize = true;
            lblRelatorioAno.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRelatorioAno.ForeColor = Color.Black;
            lblRelatorioAno.Location = new Point(262, 33);
            lblRelatorioAno.Name = "lblRelatorioAno";
            lblRelatorioAno.Size = new Size(478, 65);
            lblRelatorioAno.TabIndex = 0;
            lblRelatorioAno.Text = "Relatório - 6º Ano B";
            // 
            // Relatorios
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1370, 749);
            Controls.Add(abaSair1);
            Controls.Add(abaProfile1);
            Controls.Add(abaMenu1);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(header1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Relatorios";
            Text = "Relatorios";
            tableLayoutPanel1.ResumeLayout(false);
            panelTurmas.ResumeLayout(false);
            panelTurmas.PerformLayout();
            panel3Serie.ResumeLayout(false);
            panel3Serie.PerformLayout();
            panel2Serie.ResumeLayout(false);
            panel2Serie.PerformLayout();
            panel1Serie.ResumeLayout(false);
            panel1Serie.PerformLayout();
            panel9Ano.ResumeLayout(false);
            panel9Ano.PerformLayout();
            panel8Ano.ResumeLayout(false);
            panel8Ano.PerformLayout();
            panel7Ano.ResumeLayout(false);
            panel7Ano.PerformLayout();
            panel6Ano.ResumeLayout(false);
            panel6Ano.PerformLayout();
            panel5Ano.ResumeLayout(false);
            panel5Ano.PerformLayout();
            panel4Ano.ResumeLayout(false);
            panel4Ano.PerformLayout();
            panel3Ano.ResumeLayout(false);
            panel3Ano.PerformLayout();
            panel2Ano.ResumeLayout(false);
            panel2Ano.PerformLayout();
            panel1Ano.ResumeLayout(false);
            panel1Ano.PerformLayout();
            panelRelatorioAno.ResumeLayout(false);
            panelRelatorioAno.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Header header1;
        private AbaMenu abaMenu1;
        private abaProfile abaProfile1;
        private abaSair abaSair1;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panelTurmas;
        private Label lblTurmas;
        private Label lblEnsinoMedio;
        private Label lblFundamental2;
        private Label lblFundamental1;
        private Panel panel5Ano;
        private Panel panel4Ano;
        private Panel panel3Ano;
        private Panel panel2Ano;
        private Panel panel1Ano;
        private Label lbl1Ano;
        private Label lbl5Ano;
        private Label lbl4Ano;
        private Label lbl3Ano;
        private Label lbl2Ano;
        private Button btn1C;
        private Button btn1B;
        private Button btn1A;
        private Button btn5A;
        private Button btn5B;
        private Button btn5C;
        private Button btn4C;
        private Button btn4B;
        private Button btn4A;
        private Button btn3A;
        private Button btn3B;
        private Button btn3C;
        private Button btn2C;
        private Button btn2B;
        private Button btn2A;
        private Panel panel3Serie;
        private Button btn3sA;
        private Button btn3sB;
        private Button btn3sC;
        private Label lbl3Serie;
        private Panel panel2Serie;
        private Button btn2sA;
        private Button btn2sB;
        private Button btn2sC;
        private Label lbl2Serie;
        private Panel panel1Serie;
        private Button btn1sA;
        private Button btn1sB;
        private Button btn1sC;
        private Label lbl1Serie;
        private Panel panel9Ano;
        private Button btn9A;
        private Button btn9B;
        private Button btn9C;
        private Label lbl9Ano;
        private Panel panel8Ano;
        private Button btn8A;
        private Button btn8B;
        private Button btn8C;
        private Label lbl8Ano;
        private Panel panel7Ano;
        private Button btn7A;
        private Button btn7B;
        private Button btn7C;
        private Label lbl7Ano;
        private Panel panel6Ano;
        private Button btn6A;
        private Button btn6B;
        private Button btn6C;
        private Label lbl6ano;
        private Panel panelRelatorioAno;
        private Label lblRelatorioAno;
    }
}