﻿namespace LuminaLearning
{
    partial class Pacotes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            header1 = new Header();
            lblPlanos = new Label();
            tableLayoutPanelCards = new TableLayoutPanel();
            panel8 = new Panel();
            panel9 = new Panel();
            label4 = new Label();
            panel6 = new Panel();
            panel7 = new Panel();
            label3 = new Label();
            panel4 = new Panel();
            panel5 = new Panel();
            label2 = new Label();
            pnlCardPlano1 = new Panel();
            panel2 = new Panel();
            panel3 = new Panel();
            label1 = new Label();
            panel1 = new Panel();
            lblValorPlano1 = new Label();
            abaMenu1 = new AbaMenu();
            abaProfile1 = new abaProfile();
            abaSair1 = new abaSair();
            tableLayoutPanelCards.SuspendLayout();
            panel8.SuspendLayout();
            panel6.SuspendLayout();
            panel4.SuspendLayout();
            pnlCardPlano1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // header1
            // 
            header1.Dock = DockStyle.Top;
            header1.Location = new Point(0, 0);
            header1.Name = "header1";
            header1.Size = new Size(1370, 90);
            header1.TabIndex = 0;
            header1.OnMenuClick += header1_OnMenuClick;
            header1.OnbtnProfile += header1_OnbtnProfile;
            // 
            // lblPlanos
            // 
            lblPlanos.AutoSize = true;
            lblPlanos.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPlanos.Location = new Point(579, 142);
            lblPlanos.Name = "lblPlanos";
            lblPlanos.Size = new Size(166, 65);
            lblPlanos.TabIndex = 2;
            lblPlanos.Text = "Planos";
            // 
            // tableLayoutPanelCards
            // 
            tableLayoutPanelCards.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanelCards.ColumnCount = 4;
            tableLayoutPanelCards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanelCards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanelCards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanelCards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanelCards.Controls.Add(panel8, 3, 0);
            tableLayoutPanelCards.Controls.Add(panel6, 2, 0);
            tableLayoutPanelCards.Controls.Add(panel4, 1, 0);
            tableLayoutPanelCards.Controls.Add(pnlCardPlano1, 0, 0);
            tableLayoutPanelCards.Location = new Point(113, 290);
            tableLayoutPanelCards.Name = "tableLayoutPanelCards";
            tableLayoutPanelCards.RowCount = 1;
            tableLayoutPanelCards.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanelCards.Size = new Size(1116, 391);
            tableLayoutPanelCards.TabIndex = 3;
            tableLayoutPanelCards.Paint += tableLayoutPanelCards_Paint;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Gray;
            panel8.Controls.Add(panel9);
            panel8.Controls.Add(label4);
            panel8.Dock = DockStyle.Fill;
            panel8.Location = new Point(837, 0);
            panel8.Margin = new Padding(0);
            panel8.Name = "panel8";
            panel8.Size = new Size(279, 391);
            panel8.TabIndex = 3;
            // 
            // panel9
            // 
            panel9.BackColor = Color.Silver;
            panel9.Location = new Point(13, 53);
            panel9.Name = "panel9";
            panel9.Size = new Size(246, 303);
            panel9.TabIndex = 5;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(65, 8);
            label4.Name = "label4";
            label4.Size = new Size(136, 40);
            label4.TabIndex = 4;
            label4.Text = "R$450,00";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Gray;
            panel6.Controls.Add(panel7);
            panel6.Controls.Add(label3);
            panel6.Dock = DockStyle.Fill;
            panel6.Location = new Point(558, 0);
            panel6.Margin = new Padding(0, 0, 10, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(269, 391);
            panel6.TabIndex = 2;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Silver;
            panel7.Location = new Point(13, 53);
            panel7.Name = "panel7";
            panel7.Size = new Size(246, 303);
            panel7.TabIndex = 5;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(65, 8);
            label3.Name = "label3";
            label3.Size = new Size(136, 40);
            label3.TabIndex = 4;
            label3.Text = "R$250,00";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gray;
            panel4.Controls.Add(panel5);
            panel4.Controls.Add(label2);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(279, 0);
            panel4.Margin = new Padding(0, 0, 10, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(269, 391);
            panel4.TabIndex = 1;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Silver;
            panel5.Location = new Point(13, 53);
            panel5.Name = "panel5";
            panel5.Size = new Size(246, 303);
            panel5.TabIndex = 5;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(65, 8);
            label2.Name = "label2";
            label2.Size = new Size(136, 40);
            label2.TabIndex = 4;
            label2.Text = "R$160,00";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pnlCardPlano1
            // 
            pnlCardPlano1.BackColor = Color.Gray;
            pnlCardPlano1.Controls.Add(panel2);
            pnlCardPlano1.Controls.Add(panel1);
            pnlCardPlano1.Controls.Add(lblValorPlano1);
            pnlCardPlano1.Dock = DockStyle.Fill;
            pnlCardPlano1.Location = new Point(0, 0);
            pnlCardPlano1.Margin = new Padding(0, 0, 10, 0);
            pnlCardPlano1.Name = "pnlCardPlano1";
            pnlCardPlano1.Size = new Size(269, 391);
            pnlCardPlano1.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gray;
            panel2.Controls.Add(panel3);
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(0, 0, 10, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(269, 391);
            panel2.TabIndex = 6;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Silver;
            panel3.Location = new Point(13, 53);
            panel3.Name = "panel3";
            panel3.Size = new Size(245, 303);
            panel3.TabIndex = 5;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(65, 8);
            label1.Name = "label1";
            label1.Size = new Size(120, 40);
            label1.TabIndex = 4;
            label1.Text = "R$80,00";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Silver;
            panel1.Location = new Point(13, 53);
            panel1.Name = "panel1";
            panel1.Size = new Size(245, 303);
            panel1.TabIndex = 5;
            // 
            // lblValorPlano1
            // 
            lblValorPlano1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lblValorPlano1.AutoSize = true;
            lblValorPlano1.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblValorPlano1.Location = new Point(65, 8);
            lblValorPlano1.Name = "lblValorPlano1";
            lblValorPlano1.Size = new Size(136, 40);
            lblValorPlano1.TabIndex = 4;
            lblValorPlano1.Text = "R$100,00";
            lblValorPlano1.TextAlign = ContentAlignment.MiddleCenter;
            lblValorPlano1.Click += lblValorPlano1_Click;
            // 
            // abaMenu1
            // 
            abaMenu1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            abaMenu1.Location = new Point(1070, 90);
            abaMenu1.Name = "abaMenu1";
            abaMenu1.Size = new Size(300, 600);
            abaMenu1.TabIndex = 4;
            abaMenu1.Visible = false;
            abaMenu1.OnbtnHomeClick += abaMenu1_OnbtnHomeClick;
            abaMenu1.OnbtnCadastroClick += abaMenu1_OnbtnCadastroClick;
            abaMenu1.OnbtnLoginClick += abaMenu1_OnbtnLoginClick;
            abaMenu1.OnbtnPacotesClick += abaMenu1_OnbtnPacotesClick;
            abaMenu1.OnbtnJogosClick += abaMenu1_OnbtnJogosClick;
            // 
            // abaProfile1
            // 
            abaProfile1.BackColor = Color.FromArgb(224, 224, 224);
            abaProfile1.Location = new Point(800, 90);
            abaProfile1.Name = "abaProfile1";
            abaProfile1.Size = new Size(570, 200);
            abaProfile1.TabIndex = 5;
            abaProfile1.Visible = false;
            abaProfile1.OnbtnSairClick += abaProfile1_OnbtnSairClick;
            // 
            // abaSair1
            // 
            abaSair1.BackColor = Color.FromArgb(224, 224, 224);
            abaSair1.Location = new Point(513, 239);
            abaSair1.Name = "abaSair1";
            abaSair1.Size = new Size(309, 146);
            abaSair1.TabIndex = 0;
            abaSair1.Visible = false;
            // 
            // Pacotes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1370, 749);
            Controls.Add(abaSair1);
            Controls.Add(abaProfile1);
            Controls.Add(abaMenu1);
            Controls.Add(lblPlanos);
            Controls.Add(header1);
            Controls.Add(tableLayoutPanelCards);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Pacotes";
            Text = "        ";
            tableLayoutPanelCards.ResumeLayout(false);
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            pnlCardPlano1.ResumeLayout(false);
            pnlCardPlano1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Header header1;
        private Label lblPlanos;
        private TableLayoutPanel tableLayoutPanelCards;
        private Panel pnlCardPlano1;
        private Label lblValorPlano1;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Label label1;
        private Panel panel8;
        private Panel panel9;
        private Label label4;
        private Panel panel6;
        private Panel panel7;
        private Label label3;
        private Panel panel4;
        private Panel panel5;
        private Label label2;
        private AbaMenu abaMenu1;
        private abaProfile abaProfile1;
        private abaSair abaSair1;
    }
}