﻿namespace LuminaLearning
{
    partial class Cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblCadastro = new Label();
            header1 = new Header();
            txtNome = new TextBox();
            txtCNPJ = new TextBox();
            txtConfirmar = new TextBox();
            txtCriar = new TextBox();
            btnCadastrar = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // lblCadastro
            // 
            lblCadastro.AutoSize = true;
            lblCadastro.BackColor = Color.Silver;
            lblCadastro.FlatStyle = FlatStyle.Flat;
            lblCadastro.Font = new Font("Segoe UI", 48F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCadastro.Location = new Point(463, 168);
            lblCadastro.Name = "lblCadastro";
            lblCadastro.Size = new Size(548, 86);
            lblCadastro.TabIndex = 2;
            lblCadastro.Text = "Cadastro Empresa";
            // 
            // header1
            // 
            header1.Dock = DockStyle.Top;
            header1.Location = new Point(0, 0);
            header1.Name = "header1";
            header1.Size = new Size(1370, 90);
            header1.TabIndex = 3;
            // 
            // txtNome
            // 
            txtNome.BackColor = Color.FromArgb(224, 224, 224);
            txtNome.BorderStyle = BorderStyle.FixedSingle;
            txtNome.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNome.ForeColor = SystemColors.ControlText;
            txtNome.Location = new Point(463, 279);
            txtNome.Multiline = true;
            txtNome.Name = "txtNome";
            txtNome.PlaceholderText = "Nome";
            txtNome.Size = new Size(548, 58);
            txtNome.TabIndex = 4;
            // 
            // txtCNPJ
            // 
            txtCNPJ.BackColor = Color.FromArgb(224, 224, 224);
            txtCNPJ.BorderStyle = BorderStyle.FixedSingle;
            txtCNPJ.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCNPJ.ForeColor = SystemColors.ControlText;
            txtCNPJ.Location = new Point(463, 353);
            txtCNPJ.Multiline = true;
            txtCNPJ.Name = "txtCNPJ";
            txtCNPJ.PlaceholderText = "CNPJ";
            txtCNPJ.Size = new Size(548, 58);
            txtCNPJ.TabIndex = 5;
            // 
            // txtConfirmar
            // 
            txtConfirmar.BackColor = Color.FromArgb(224, 224, 224);
            txtConfirmar.BorderStyle = BorderStyle.FixedSingle;
            txtConfirmar.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtConfirmar.ForeColor = SystemColors.ControlText;
            txtConfirmar.Location = new Point(463, 525);
            txtConfirmar.Multiline = true;
            txtConfirmar.Name = "txtConfirmar";
            txtConfirmar.PlaceholderText = "Confirmar Senha";
            txtConfirmar.Size = new Size(548, 58);
            txtConfirmar.TabIndex = 6;
            // 
            // txtCriar
            // 
            txtCriar.BackColor = Color.FromArgb(224, 224, 224);
            txtCriar.BorderStyle = BorderStyle.FixedSingle;
            txtCriar.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCriar.ForeColor = SystemColors.ControlText;
            txtCriar.Location = new Point(463, 435);
            txtCriar.Multiline = true;
            txtCriar.Name = "txtCriar";
            txtCriar.PlaceholderText = "Criar Senha";
            txtCriar.Size = new Size(548, 58);
            txtCriar.TabIndex = 7;
            // 
            // btnCadastrar
            // 
            btnCadastrar.BackColor = Color.Silver;
            btnCadastrar.FlatAppearance.BorderSize = 0;
            btnCadastrar.FlatAppearance.MouseDownBackColor = Color.Gray;
            btnCadastrar.FlatAppearance.MouseOverBackColor = Color.Gray;
            btnCadastrar.FlatStyle = FlatStyle.Flat;
            btnCadastrar.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCadastrar.Location = new Point(637, 603);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(213, 58);
            btnCadastrar.TabIndex = 8;
            btnCadastrar.Text = "CADASTRAR";
            btnCadastrar.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.Location = new Point(229, 314);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 9;
            button1.Text = "teste";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Cadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1370, 749);
            Controls.Add(button1);
            Controls.Add(btnCadastrar);
            Controls.Add(txtCriar);
            Controls.Add(txtConfirmar);
            Controls.Add(txtCNPJ);
            Controls.Add(txtNome);
            Controls.Add(header1);
            Controls.Add(lblCadastro);
            Name = "Cadastro";
            Text = "Cadastro";
            Load += Cadastro_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblCadastro;
        private Header header1;
        private TextBox txtNome;
        private TextBox txtCNPJ;
        private TextBox txtConfirmar;
        private TextBox txtCriar;
        private Button btnCadastrar;
        private Button button1;
    }
}