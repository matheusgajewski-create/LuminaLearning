﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LuminaLearning
{
    public partial class Jogos : Form
    {
        public Jogos()
        {
            InitializeComponent();
        }

        private void lblAcessos_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Jogos_Load(object sender, EventArgs e)
        {

        }
    }
}
