﻿namespace LuminaLearning
{
    partial class Home
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblMessier = new Label();
            btnCadastrar = new Button();
            btnJogo1 = new Button();
            btnJogo3 = new Button();
            btnJogo2 = new Button();
            btnJogo4 = new Button();
            header1 = new Header();
            button1 = new Button();
            SuspendLayout();
            // 
            // lblMessier
            // 
            lblMessier.Anchor = AnchorStyles.None;
            lblMessier.AutoSize = true;
            lblMessier.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblMessier.Location = new Point(472, 167);
            lblMessier.Name = "lblMessier";
            lblMessier.Size = new Size(523, 65);
            lblMessier.TabIndex = 1;
            lblMessier.Text = "Messier data && creative";
            lblMessier.Click += lblMessier_Click;
            // 
            // btnCadastrar
            // 
            btnCadastrar.Anchor = AnchorStyles.None;
            btnCadastrar.BackColor = Color.FromArgb(224, 224, 224);
            btnCadastrar.FlatAppearance.BorderSize = 0;
            btnCadastrar.FlatAppearance.MouseDownBackColor = Color.Silver;
            btnCadastrar.FlatAppearance.MouseOverBackColor = Color.Silver;
            btnCadastrar.FlatStyle = FlatStyle.Flat;
            btnCadastrar.Font = new Font("Segoe UI", 48F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCadastrar.Location = new Point(454, 235);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(556, 96);
            btnCadastrar.TabIndex = 2;
            btnCadastrar.Text = "Cadastro Empresa";
            btnCadastrar.UseVisualStyleBackColor = false;
            btnCadastrar.Click += btnCadastrar_Click;
            // 
            // btnJogo1
            // 
            btnJogo1.Anchor = AnchorStyles.Bottom;
            btnJogo1.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo1.FlatAppearance.BorderColor = Color.Gray;
            btnJogo1.FlatAppearance.BorderSize = 8;
            btnJogo1.FlatStyle = FlatStyle.Flat;
            btnJogo1.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo1.Location = new Point(31, 650);
            btnJogo1.Name = "btnJogo1";
            btnJogo1.Size = new Size(308, 170);
            btnJogo1.TabIndex = 3;
            btnJogo1.Text = "JOGO 1";
            btnJogo1.UseVisualStyleBackColor = false;
            // 
            // btnJogo3
            // 
            btnJogo3.Anchor = AnchorStyles.Bottom;
            btnJogo3.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo3.FlatAppearance.BorderColor = Color.Gray;
            btnJogo3.FlatAppearance.BorderSize = 8;
            btnJogo3.FlatStyle = FlatStyle.Flat;
            btnJogo3.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo3.Location = new Point(734, 650);
            btnJogo3.Name = "btnJogo3";
            btnJogo3.Size = new Size(308, 170);
            btnJogo3.TabIndex = 4;
            btnJogo3.Text = "JOGO 3";
            btnJogo3.UseVisualStyleBackColor = false;
            // 
            // btnJogo2
            // 
            btnJogo2.Anchor = AnchorStyles.Bottom;
            btnJogo2.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo2.FlatAppearance.BorderColor = Color.Gray;
            btnJogo2.FlatAppearance.BorderSize = 8;
            btnJogo2.FlatStyle = FlatStyle.Flat;
            btnJogo2.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo2.Location = new Point(384, 650);
            btnJogo2.Name = "btnJogo2";
            btnJogo2.Size = new Size(308, 170);
            btnJogo2.TabIndex = 5;
            btnJogo2.Text = "JOGO 2";
            btnJogo2.UseVisualStyleBackColor = false;
            // 
            // btnJogo4
            // 
            btnJogo4.Anchor = AnchorStyles.Bottom;
            btnJogo4.BackColor = Color.FromArgb(224, 224, 224);
            btnJogo4.FlatAppearance.BorderColor = Color.Gray;
            btnJogo4.FlatAppearance.BorderSize = 8;
            btnJogo4.FlatStyle = FlatStyle.Flat;
            btnJogo4.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogo4.Location = new Point(1082, 650);
            btnJogo4.Name = "btnJogo4";
            btnJogo4.Size = new Size(308, 170);
            btnJogo4.TabIndex = 6;
            btnJogo4.Text = "JOGO 4";
            btnJogo4.UseVisualStyleBackColor = false;
            // 
            // header1
            // 
            header1.Dock = DockStyle.Top;
            header1.Location = new Point(0, 0);
            header1.Name = "header1";
            header1.Size = new Size(1424, 90);
            header1.TabIndex = 7;
            // 
            // button1
            // 
            button1.Location = new Point(347, 386);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 8;
            button1.Text = "teste";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1424, 861);
            Controls.Add(button1);
            Controls.Add(header1);
            Controls.Add(btnJogo4);
            Controls.Add(btnJogo2);
            Controls.Add(btnJogo3);
            Controls.Add(lblMessier);
            Controls.Add(btnJogo1);
            Controls.Add(btnCadastrar);
            Name = "Home";
            Text = "Home";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblMessier;
        private Button btnCadastrar;
        private Button btnJogo1;
        private Button btnJogo3;
        private Button btnJogo2;
        private Button btnJogo4;
        private Header header1;
        private Button button1;
    }
}
