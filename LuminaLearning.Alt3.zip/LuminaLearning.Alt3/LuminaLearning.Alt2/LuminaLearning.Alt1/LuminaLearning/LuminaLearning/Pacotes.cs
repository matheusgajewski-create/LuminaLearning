﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LuminaLearning
{
    public partial class Pacotes : Form
    {
        public Pacotes()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Jogos tela = new Jogos();
            tela.Show();
        }

        private void lblValorPlano1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanelCards_Paint(object sender, PaintEventArgs e)
        {

        }

        private void header1_OnMenuClick(object sender, EventArgs e)
        {
            abaMenu1.Visible = !abaMenu1.Visible;

            if (abaMenu1.Visible)
            {
                abaMenu1.BringToFront(); // Garante que ele fique na frente de tudo
            }
        }
    }
}
