﻿namespace LuminaLearning
{
    partial class Header
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button2 = new Button();
            button1 = new Button();
            btnLogo = new Button();
            btnUser = new Button();
            btnMenu = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDark;
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(btnLogo);
            panel1.Controls.Add(btnUser);
            panel1.Controls.Add(btnMenu);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1424, 90);
            panel1.TabIndex = 1;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button2.BackgroundImage = Properties.Resources.bars_solid;
            button2.BackgroundImageLayout = ImageLayout.Zoom;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Location = new Point(1326, 12);
            button2.Name = "button2";
            button2.Size = new Size(65, 54);
            button2.TabIndex = 5;
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button1.BackgroundImage = Properties.Resources.circle_user_regular;
            button1.BackgroundImageLayout = ImageLayout.Zoom;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Location = new Point(1255, 12);
            button1.Name = "button1";
            button1.Size = new Size(65, 54);
            button1.TabIndex = 4;
            button1.UseVisualStyleBackColor = true;
            // 
            // btnLogo
            // 
            btnLogo.BackgroundImage = Properties.Resources.messier_logo;
            btnLogo.BackgroundImageLayout = ImageLayout.Zoom;
            btnLogo.FlatAppearance.BorderSize = 0;
            btnLogo.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnLogo.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnLogo.FlatStyle = FlatStyle.Flat;
            btnLogo.Location = new Point(31, 12);
            btnLogo.Name = "btnLogo";
            btnLogo.Size = new Size(56, 54);
            btnLogo.TabIndex = 3;
            btnLogo.UseVisualStyleBackColor = true;
            // 
            // btnUser
            // 
            btnUser.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnUser.BackgroundImage = Properties.Resources.circle_user_regular;
            btnUser.BackgroundImageLayout = ImageLayout.Zoom;
            btnUser.FlatAppearance.BorderSize = 0;
            btnUser.FlatStyle = FlatStyle.Flat;
            btnUser.Location = new Point(2478, 12);
            btnUser.Name = "btnUser";
            btnUser.Size = new Size(65, 54);
            btnUser.TabIndex = 2;
            btnUser.UseVisualStyleBackColor = true;
            // 
            // btnMenu
            // 
            btnMenu.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMenu.BackgroundImage = Properties.Resources.bars_solid;
            btnMenu.BackgroundImageLayout = ImageLayout.Zoom;
            btnMenu.FlatAppearance.BorderSize = 0;
            btnMenu.FlatStyle = FlatStyle.Flat;
            btnMenu.Location = new Point(2549, 12);
            btnMenu.Name = "btnMenu";
            btnMenu.Size = new Size(65, 54);
            btnMenu.TabIndex = 1;
            btnMenu.UseVisualStyleBackColor = true;
            // 
            // Header
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "Header";
            Size = new Size(1424, 90);
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button btnLogo;
        private Button btnUser;
        private Button btnMenu;
        private Button button1;
        private Button button2;
    }
}
