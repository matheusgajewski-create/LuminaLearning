﻿namespace LuminaLearning
{
    partial class AbaMenu
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            pictureBoxSair = new PictureBox();
            pictureBoxJogos = new PictureBox();
            pictureBoxPacotes = new PictureBox();
            pictureBoxLogin = new PictureBox();
            pictureBoxCadastro = new PictureBox();
            pictureBoxHome = new PictureBox();
            btnSair = new Button();
            btnJogos = new Button();
            btnPacotes = new Button();
            btnLogin = new Button();
            btnCadastro = new Button();
            btnHome = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxSair).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxJogos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPacotes).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxLogin).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCadastro).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxHome).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gray;
            panel1.Controls.Add(pictureBoxSair);
            panel1.Controls.Add(pictureBoxJogos);
            panel1.Controls.Add(pictureBoxPacotes);
            panel1.Controls.Add(pictureBoxLogin);
            panel1.Controls.Add(pictureBoxCadastro);
            panel1.Controls.Add(pictureBoxHome);
            panel1.Controls.Add(btnSair);
            panel1.Controls.Add(btnJogos);
            panel1.Controls.Add(btnPacotes);
            panel1.Controls.Add(btnLogin);
            panel1.Controls.Add(btnCadastro);
            panel1.Controls.Add(btnHome);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(300, 600);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // pictureBoxSair
            // 
            pictureBoxSair.BackgroundImage = Properties.Resources.arrow_right_from_bracket_solid1;
            pictureBoxSair.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBoxSair.Location = new Point(6, 515);
            pictureBoxSair.Name = "pictureBoxSair";
            pictureBoxSair.Size = new Size(76, 64);
            pictureBoxSair.TabIndex = 11;
            pictureBoxSair.TabStop = false;
            // 
            // pictureBoxJogos
            // 
            pictureBoxJogos.BackgroundImage = Properties.Resources.gamepad_solid;
            pictureBoxJogos.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBoxJogos.Location = new Point(6, 413);
            pictureBoxJogos.Name = "pictureBoxJogos";
            pictureBoxJogos.Size = new Size(76, 64);
            pictureBoxJogos.TabIndex = 10;
            pictureBoxJogos.TabStop = false;
            // 
            // pictureBoxPacotes
            // 
            pictureBoxPacotes.BackgroundImage = Properties.Resources.box_solid;
            pictureBoxPacotes.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBoxPacotes.Location = new Point(6, 313);
            pictureBoxPacotes.Name = "pictureBoxPacotes";
            pictureBoxPacotes.Size = new Size(76, 64);
            pictureBoxPacotes.TabIndex = 9;
            pictureBoxPacotes.TabStop = false;
            // 
            // pictureBoxLogin
            // 
            pictureBoxLogin.BackgroundImage = Properties.Resources.circle_user_regular;
            pictureBoxLogin.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBoxLogin.Location = new Point(6, 213);
            pictureBoxLogin.Name = "pictureBoxLogin";
            pictureBoxLogin.Size = new Size(76, 64);
            pictureBoxLogin.TabIndex = 8;
            pictureBoxLogin.TabStop = false;
            // 
            // pictureBoxCadastro
            // 
            pictureBoxCadastro.BackgroundImage = Properties.Resources.user_plus_solid;
            pictureBoxCadastro.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBoxCadastro.Location = new Point(6, 116);
            pictureBoxCadastro.Name = "pictureBoxCadastro";
            pictureBoxCadastro.Size = new Size(76, 64);
            pictureBoxCadastro.TabIndex = 7;
            pictureBoxCadastro.TabStop = false;
            // 
            // pictureBoxHome
            // 
            pictureBoxHome.BackgroundImage = Properties.Resources.house_solid;
            pictureBoxHome.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBoxHome.Location = new Point(6, 20);
            pictureBoxHome.Name = "pictureBoxHome";
            pictureBoxHome.Size = new Size(76, 64);
            pictureBoxHome.TabIndex = 6;
            pictureBoxHome.TabStop = false;
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSair.Location = new Point(85, 515);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(202, 64);
            btnSair.TabIndex = 5;
            btnSair.Text = "SAIR";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnJogos
            // 
            btnJogos.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnJogos.Location = new Point(85, 413);
            btnJogos.Name = "btnJogos";
            btnJogos.Size = new Size(202, 64);
            btnJogos.TabIndex = 4;
            btnJogos.Text = "JOGOS";
            btnJogos.UseVisualStyleBackColor = true;
            btnJogos.Click += btnJogos_Click;
            // 
            // btnPacotes
            // 
            btnPacotes.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnPacotes.Location = new Point(85, 313);
            btnPacotes.Name = "btnPacotes";
            btnPacotes.Size = new Size(202, 64);
            btnPacotes.TabIndex = 3;
            btnPacotes.Text = "PACOTES";
            btnPacotes.UseVisualStyleBackColor = true;
            btnPacotes.Click += btnPacotes_Click;
            // 
            // btnLogin
            // 
            btnLogin.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnLogin.Location = new Point(85, 213);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(202, 64);
            btnLogin.TabIndex = 2;
            btnLogin.Text = "LOGIN";
            btnLogin.UseVisualStyleBackColor = true;
            btnLogin.Click += btnLogin_Click;
            // 
            // btnCadastro
            // 
            btnCadastro.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCadastro.Location = new Point(85, 116);
            btnCadastro.Name = "btnCadastro";
            btnCadastro.Size = new Size(202, 64);
            btnCadastro.TabIndex = 1;
            btnCadastro.Text = "CADASTRO";
            btnCadastro.UseVisualStyleBackColor = true;
            btnCadastro.Click += btnCadastro_Click;
            // 
            // btnHome
            // 
            btnHome.BackgroundImageLayout = ImageLayout.None;
            btnHome.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnHome.Location = new Point(85, 20);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(202, 64);
            btnHome.TabIndex = 0;
            btnHome.Text = "HOME";
            btnHome.UseVisualStyleBackColor = true;
            btnHome.Click += btnHome_Click;
            // 
            // AbaMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "AbaMenu";
            Size = new Size(300, 600);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBoxSair).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxJogos).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPacotes).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxLogin).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCadastro).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxHome).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button btnJogos;
        private Button btnPacotes;
        private Button btnLogin;
        private Button btnCadastro;
        private Button btnHome;
        private Button btnSair;
        private PictureBox pictureBoxSair;
        private PictureBox pictureBoxJogos;
        private PictureBox pictureBoxPacotes;
        private PictureBox pictureBoxLogin;
        private PictureBox pictureBoxCadastro;
        private PictureBox pictureBoxHome;
    }
}
